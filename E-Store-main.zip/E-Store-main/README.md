# E-Store
This is an e-commerce webpage that I made as a project in Internshala Web-Development Training. This is a simple e-commerce webpage used to sell mobile phones. technologies used are HTML, CSS, Bootstrap, PHP, and SQL.
